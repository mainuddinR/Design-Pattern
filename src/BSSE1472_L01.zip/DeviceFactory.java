package FactoryMethodLab01;

public abstract class DeviceFactory {
    public abstract Device createDevice();
}




