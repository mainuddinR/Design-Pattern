package FactoryMethodLab01;

public interface Device {
	    void powerOn();
	    void powerOff();
	    String getDeviceInfo();
}

