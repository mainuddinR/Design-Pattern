package BSSE1472_L04_Q2;

public class NotificationService {
    public void sendPaymentNotification(String cardNumber) {
        System.out.println("Sending payment notification for card: " + cardNumber);
    }
}

