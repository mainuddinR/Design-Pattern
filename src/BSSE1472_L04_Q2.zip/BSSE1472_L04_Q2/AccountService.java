package BSSE1472_L04_Q2;

public class AccountService {
    public boolean checkAccount(String cardNumber) {
        System.out.println("Checking account for card: " + cardNumber);
        return true;
    }
}
