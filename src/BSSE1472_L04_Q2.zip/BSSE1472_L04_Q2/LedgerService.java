package BSSE1472_L04_Q2;

public class LedgerService {
    public void makeLedgerEntry(String cardNumber, double amount) {
        System.out.println("Making ledger entry for card: " + cardNumber + " with amount $" + amount);
    }
}
